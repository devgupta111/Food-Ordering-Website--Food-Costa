const foodItems = [
    { id: 1, name: "Pizza", price: 299, image: "pizza.webp" },
    { id: 2, name: "Burger", price: 99, image: "burger.jpeg" },
    { id: 3, name: "Biryani", price: 249, image: "biryani.avif" },
    { id: 4, name: "Noodles", price: 199, image: "noodles.jpeg" },
    { id: 5, name: "Roll", price: 85, image: "roll.jpg" },
    { id: 6, name: "Gol Gappe", price: 49, image: "https://static.toiimg.com/photo/75107900.cms" },
    { id: 7, name: "Vada", price: 69, image: "vada.jpeg" }
];