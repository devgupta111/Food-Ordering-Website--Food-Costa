const cartTable = document.getElementById('cartTable');
const cartItems = document.getElementById('cartItems');
const totalPriceElement = document.getElementById('totalPrice');
const proceedBtn = document.getElementById('proceedBtn');
const emptyCartMessage = document.getElementById('emptyCart');

function getCart() {
    return JSON.parse(localStorage.getItem('cart')) || [];
}

function saveCart(cart) {
    localStorage.setItem('cart', JSON.stringify(cart));
}

function updateCartDisplay() {
    const cart = getCart();
    cartItems.innerHTML = '';
    let total = 0;

    if (cart.length === 0) {
        cartTable.style.display = 'none';
        totalPriceElement.style.display = 'none';
        proceedBtn.style.display = 'none';
        emptyCartMessage.style.display = 'block';
        return;
    }

    cartTable.style.display = 'table';
    totalPriceElement.style.display = 'block';
    proceedBtn.style.display = 'block';
    emptyCartMessage.style.display = 'none';

    cart.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><img src="${item.image}" alt="${item.name}" class="item-image"></td>
            <td>Food Costa</td>
            <td>${item.name}</td>
            <td>
                <div class="quantity-control">
                    <button class="quantity-btn" data-id="${item.id}" data-action="decrease">-</button>
                    <span class="quantity">${item.quantity}</span>
                    <button class="quantity-btn" data-id="${item.id}" data-action="increase">+</button>
                </div>
            </td>
            <td>Rs. ${item.price * item.quantity}</td>
            <td><button class="remove-btn" data-id="${item.id}">Remove</button></td>
        `;
        cartItems.appendChild(row);
        total += item.price * item.quantity;
    });

    totalPriceElement.textContent = `Total: Rs. ${total}`;
}

function updateQuantity(id, action) {
    const cart = getCart();
    const itemIndex = cart.findIndex(item => item.id === id);

    if (itemIndex !== -1) {
        if (action === 'increase') {
            cart[itemIndex].quantity += 1;
        } else if (action === 'decrease') {
            cart[itemIndex].quantity -= 1;
            if (cart[itemIndex].quantity === 0) {
                cart.splice(itemIndex, 1);
            }
        }
        saveCart(cart);
        updateCartDisplay();
    }
}

function removeItem(id) {
    const cart = getCart();
    const updatedCart = cart.filter(item => item.id !== id);
    saveCart(updatedCart);
    updateCartDisplay();
}

document.addEventListener('click', function(e) {
    if (e.target.classList.contains('quantity-btn')) {
        const id = parseInt(e.target.getAttribute('data-id'));
        const action = e.target.getAttribute('data-action');
        updateQuantity(id, action);
    } else if (e.target.classList.contains('remove-btn')) {
        const id = parseInt(e.target.getAttribute('data-id'));
        removeItem(id);
    }
});

// Initialize the cart display
updateCartDisplay();